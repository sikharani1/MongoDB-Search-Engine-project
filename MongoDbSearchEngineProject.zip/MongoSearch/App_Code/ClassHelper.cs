﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Driver;
using MongoDB.Bson;

/// <summary>
/// Summary description for ClassHelper
/// </summary>
public class ClassHelper
{
    public ClassHelper()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    /// <summary>
    /// This is a Bson class to representing Comment collection in MongoDb
    /// </summary>
    public class CommentMongo
    {
        public ObjectId _id { get; set; }
        public int episodeId { get; set; }
        public string commentUser { get; set; }
        public string comment { get; set; }
    }
    /// <summary>
    /// This is a Bson class to representing Episode collection in MongoDb
    /// </summary>
    public class EpisodeMongo
    {
        public ObjectId _id { get; set; }
        public int episodeId { get; set; }
        public string title { get; set; }
        public string originalAirDate { get; set; }
        public int season { get; set; }
        public int numberInSeason { get; set; }
        public int numberInSeries { get; set; }
        public double usViewers { get; set; }
        public double imdbRating { get; set; }
        public string imageURL { get; set; }
        public string videoURL { get; set; }
    }
}