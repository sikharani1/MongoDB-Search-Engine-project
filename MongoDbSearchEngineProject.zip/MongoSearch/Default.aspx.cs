﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MongoDB.Driver;
using MongoDB.Bson;

/// <summary>
/// This web application is connect to MongoDb in order to retrieve data based on the requested text in the search box
/// </summary>
public partial class _Default : System.Web.UI.Page
{
    protected MongoClient client = null;
    protected IMongoDatabase database = null;
    protected IMongoCollection<ClassHelper.EpisodeMongo> collection = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        // 1st Requirement
        client = new MongoClient("mongodb://localhost:27017");
        lblconn.Text = client == null ? "Connnection is not established" : "Connnection is established";
        database = client.GetDatabase("simpsonsdb");
        lblconn.Text = database == null
            ? lblconn.Text + "<br/>" + "Database is not selected"
            : lblconn.Text + "<br/>" + "Database is selected";
        collection = database.GetCollection<ClassHelper.EpisodeMongo>("episodes");
        lblconn.Text = collection == null
            ? lblconn.Text + "<br/>" + "Collection is not selected"
            : lblconn.Text + "<br/>" + "Collection is selected";
        //Connection to the database is successful and demonstrated
    }

    /// <summary>
    ///This function is to search for The Simpsons episodes using the title
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSearch_Click(object sender, EventArgs e)
    // 5th Requirement //GUI Screen solicits required information from the user
    {
        // 1st Requirement

        client = new MongoClient("mongodb://localhost:27017");
        lblconn.Text = client == null ? "Connnection is not established" : "Connnection is established";
        database = client.GetDatabase("simpsonsdb");
        lblconn.Text = database == null
            ? lblconn.Text + "<br/>" + "Database is not selected"
            : lblconn.Text + "<br/>" + "Database is selected";
        collection = database.GetCollection<ClassHelper.EpisodeMongo>("episodes");
        lblconn.Text = collection == null
            ? lblconn.Text + "<br/>" + "Collection is not selected"
            : lblconn.Text + "<br/>" + "Collection is selected";
        //Connection to the database is successful and demonstrated

        if (!string.IsNullOrEmpty(txtSearch.Text))
        {
            string episodeTitle = txtSearch.Text;
            lbltxt.Text = "";
            try
            {
                var episodes = collection.Find(r => Regex.IsMatch(r.title, "\\b " + episodeTitle + ".* ", RegexOptions.IgnoreCase)).ToListAsync().Result; // 2nd Requirement //Partial word search using Regex
                lblconn.Text = lblconn.Text + "<br/>" + "Connnected to MongoDb";

                if (episodes.Count == 0) //Check if zero results retriveed
                {
                    lbltxt.Text = "Sorry, No episods. You need to enter correct title please";
                }

                foreach (var episode in episodes)
                {
                    lbltxt.Text = lbltxt.Text + "<li><a href='Episode.aspx?Id=" + episode.episodeId + "'>" + episode.title + "</a></li><br/>"; // 3rd Requirement //Document list is returned to the user for selection
                }
            }
            catch // (Exception)
            {

                lblconn.Text = "Please check the connnection with MongoDb";
            }


        }
        else
        {
            lbltxt.Text = "Sorry, You need to enter episode title please";
        }

    }


    /// <summary>
    /// This function is to quit the connnection to MongoDb.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnQuit_Click(object sender, EventArgs e)
    {
        client = null; //close the connnection
        database = null;
        collection = null;
        lblconn.Text = "Connnection is ended";

    }
}