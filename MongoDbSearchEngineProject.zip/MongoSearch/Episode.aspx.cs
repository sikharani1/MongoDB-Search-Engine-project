﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MongoDB.Driver;
using MongoDB.Bson;

public partial class Episode : System.Web.UI.Page
{
    public int eId = 0;

    protected void Page_Load(object sender, EventArgs e)
    // 4th Requirement //User can select the document to view and selected document is returned to the user

    {
        string strID = Request.QueryString["Id"];
        if (strID != null)
        {
            eId = int.Parse(strID);
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("simpsonsdb");
            var collection = database.GetCollection<ClassHelper.EpisodeMongo>("episodes");
            var commentscollection = database.GetCollection<ClassHelper.CommentMongo>("comments");
            lblComment.Text = "";


            if (eId != 0)
            {
                try
                {
                    var episodes = collection.Find(s => s.episodeId == eId).ToListAsync().Result; // retrieving comment and episode information
                    foreach (var episode in episodes)
                    {
                        imgEpisode.ImageUrl = episode.imageURL; //Images are returned with the document
                        lblTitle.Text = episode.title;
                        LblEpisodeNumber.Text = episode.numberInSeason.ToString();
                        lblSeasonNumber.Text = episode.season.ToString();
                        lblUSViews.Text = episode.usViewers.ToString();
                        lblOriginalAirDate.Text = episode.originalAirDate;
                        lblImdbRating.Text = episode.imdbRating.ToString();
                        hlVideoURL.NavigateUrl = episode.videoURL;
                    }
                    var comments = commentscollection.Find(s => s.episodeId == eId).ToListAsync().Result;
                    foreach (var comment in comments)
                    {
                        lblComment.Text = lblComment.Text + "</br>" + comment.commentUser + ":&nbsp;</ br >" +
                                          comment.comment; //User comments are retrieved with the documents

                    }
                }
                catch (Exception)
                {

                    Response.Redirect("~/Default.aspx");
                }
            }
            else
            {
                Response.Redirect("~/Default.aspx");
            }
        }
        else
        {
            Response.Redirect("~/Default.aspx");
        }
    }

    protected void btnAddComment_Click(object sender, EventArgs e) //User comments can be added to the documents
    {
        var client = new MongoClient("mongodb://localhost:27017");
        var database = client.GetDatabase("simpsonsdb");
        var collection = database.GetCollection<ClassHelper.CommentMongo>("comments");
        if (!string.IsNullOrEmpty(txtComment.Text) && !string.IsNullOrEmpty(txtCommentUser.Text))
        {
            try
            {
                string episodeCommentUser = txtCommentUser.Text;
                string episodeComment = txtComment.Text; // adding comment to the current episode
                collection.InsertOneAsync(new ClassHelper.CommentMongo { episodeId = eId, commentUser = episodeCommentUser, comment = episodeComment });
                Response.Redirect("Episode.aspx?Id=" + eId);
            }
            catch //(Exception)
            {

                Response.Redirect("~/Default.aspx");
            }
        }
        else
        {
        }
    }


}